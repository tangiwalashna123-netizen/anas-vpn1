package com.nasrat.anasvpn

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF142B49)
private val Blue = Color(0xFF42678F)
private val Gold = Color(0xFFFFDF16)
private val Pale = Color(0xFFF3F6FA)
private val Muted = Color(0xFF9EADC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Blue,
                    secondary = Gold,
                    background = Pale,
                    surface = Color.White
                )
            ) {
                AnasVpnScreen(
                    onConnect = {
                        Toast.makeText(
                            this,
                            "WireGuard server setup is required before connecting.",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    onWhatsApp = {
                        val phone = "93767490103"
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone"))
                        startActivity(intent)
                    }
                )
            }
        }
    }
}

@Composable
fun AnasVpnScreen(onConnect: () -> Unit, onWhatsApp: () -> Unit) {
    var showAbout by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = Pale) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 22.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "ANAS VPN",
                        color = Navy,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        "SECURE • PRIVATE • SIMPLE",
                        color = Blue,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.4.sp
                    )
                }
                IconButton(onClick = { showAbout = true }) {
                    Icon(Icons.Default.Info, contentDescription = "About ANAS VPN", tint = Navy)
                }
            }

            Spacer(Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Navy),
                elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 26.dp, horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "YOUR CONNECTION",
                        color = Muted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(Modifier.height(18.dp))

                    // The supplied Nasrat logo is the main tap-to-connect control.
                    Box(
                        modifier = Modifier
                            .size(236.dp)
                            .clip(CircleShape)
                            .clickable { onConnect() },
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.anas_logo),
                            contentDescription = "Tap to connect to ANAS VPN",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(Modifier.height(18.dp))
                    Text(
                        "TAP THE LOGO TO CONNECT",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Server setup required",
                        color = Gold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                InfoTile(
                    modifier = Modifier.weight(1f),
                    icon = { Icon(Icons.Default.Lock, null, tint = Blue) },
                    title = "PROTOCOL",
                    value = "WireGuard"
                )
                InfoTile(
                    modifier = Modifier.weight(1f),
                    icon = { Icon(Icons.Default.Language, null, tint = Blue) },
                    title = "NETWORK",
                    value = "Not connected"
                )
            }

            Spacer(Modifier.weight(1f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.White)
                    .clickable { showAbout = true }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = Blue)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ABOUT US", color = Navy, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Created by Nasrat Wardak", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.Settings, contentDescription = null, tint = Muted)
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "ANAS VPN  •  VERSION 1.0",
                color = Muted,
                fontSize = 10.sp,
                letterSpacing = 1.2.sp
            )
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            confirmButton = {
                TextButton(onClick = onWhatsApp) { Text("CONTACT ON WHATSAPP") }
            },
            dismissButton = {
                TextButton(onClick = { showAbout = false }) { Text("CLOSE") }
            },
            title = {
                Text("ABOUT ANAS VPN", color = Navy, fontWeight = FontWeight.ExtraBold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Created by Nasrat Wardak", fontWeight = FontWeight.SemiBold)
                    Text("Name: Nasrat Tangiwal")
                    Text("Phone: 0093784806869")
                    Text("WhatsApp: 0093767490103")
                }
            },
            containerColor = Color.White
        )
    }
}

@Composable
private fun InfoTile(
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit,
    title: String,
    value: String
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier.padding(15.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            icon()
            Text(title, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = Navy, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
