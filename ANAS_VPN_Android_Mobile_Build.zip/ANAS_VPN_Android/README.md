# ANAS VPN — Android Studio project

This is the first Android app UI build for ANAS VPN. It uses the supplied Nasrat logo as the large tap target and uses clean English typography throughout.

## Current status
- App name: ANAS VPN
- Creator: Nasrat Wardak
- Contact details are shown in About Us.
- The supplied image is used as the main tap-to-connect control.
- WireGuard is selected as the intended VPN protocol.
- The Connect tap currently shows a clear setup-required message. It does **not** claim to establish a VPN connection.

## Important: server configuration is still needed
A real VPN requires a working WireGuard server and a client configuration for this app/device. Do not put a private server key in public source code or share it in screenshots. Before enabling real connections, the app must integrate the WireGuard Android tunnel library and request Android's VPN permission through `VpnService.prepare()`.

## Build
1. Install Android Studio (current stable) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be created under `app/build/outputs/apk/debug/`.

## Brand
- Product: ANAS VPN
- Creator: Nasrat Wardak
- Phone: 0093784806869
- WhatsApp: 0093767490103
- Typography: Android Sans Serif (clean English UI font)
